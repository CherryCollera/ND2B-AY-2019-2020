﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class car
{
    private string color;
    public car(string color)
    {
        this.color = color;
    }
    public string Describe()
    {
        return "this car is " + color;
    }
}
class Declaration
{
    public string Color
    {
        get
        {
            return Color;
        }
        set
        {
            Color = value;
        }
    }
}
namespace ClassExample2_DelaCruz
{
    class Program
    {
        static void Main(string[] args)
        {
            car car;
            car = new car("Red");
            Console.WriteLine(car.Describe());
            car = new car("green");
            Console.WriteLine(car.Describe());
            Console.ReadKey();
        }
    }
}
