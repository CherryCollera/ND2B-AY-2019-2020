﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Accept
{
    public string firstname, lastname;
    public void AcceptDetails()
    {
        System.Console.WriteLine("Enter your first and lastname:\t");
        firstname = System.Console.ReadLine();
        lastname = System.Console.ReadLine();
    }

}
class print
{
    public void PrintDetails()
    {
        Accept a = new Accept();
        a.AcceptDetails();
        System.Console.WriteLine("Hello "+ a.firstname+ "" + a.lastname + "!!!\nYou have created classes in OOP");
        Myprofile mp = new Myprofile();
        mp.Displayprofile();
    }
}
class Myprofile
{
    public void Displayprofile()
    {
        System.Console.WriteLine("\n\n\n\t\t\tP R O F I L E");
        System.Console.WriteLine("Name:\t\t\tRheymel Justine Dela Cruz");
        System.Console.WriteLine("Birthday:\t\tOctober 27,1999");
        System.Console.WriteLine("Course:\t\t\tBS Computer Science Major in Network and Data Communication");
        System.Console.WriteLine("Year:\t\t\t2nd Year");
        System.Console.WriteLine("Section:\t\t\tB");
        System.Console.ReadKey();
    }
}
namespace Lab4Exercise_DelaCruz
{
    class ClassExample1_DelaCruz
    {
        static void Main(string[] args)
        {
            print p = new print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
