﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation_DelaCruz
{
    class Remainder
    {
        public void ComputedRem()
        {
            DeclaringVar.remainder = DeclaringVar.num1 % DeclaringVar.num2;
        }
    }
}
