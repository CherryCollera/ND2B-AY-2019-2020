﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation_DelaCruz
{
    class Input
    {
        public void InputValue()
        {
            try
            {
                System.Console.Write("Enter the first Number: ");
                DeclaringVar.num1 = System.Convert.ToInt32(Console.ReadLine());
                System.Console.Write("Enter the second Number: ");
                DeclaringVar.num2 = System.Convert.ToInt32(Console.ReadLine());
               
            }
            catch(System.FormatException ex)
            {
                System.Console.Error.WriteLine(ex.Message);
                //throw;
            }
        }
    }
}
