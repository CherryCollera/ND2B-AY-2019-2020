﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation_DelaCruz
{
    class Product
    {
        public void ComputedPro()
        {
            DeclaringVar.product = DeclaringVar.num1 * DeclaringVar.num2;
        }
    }
}
