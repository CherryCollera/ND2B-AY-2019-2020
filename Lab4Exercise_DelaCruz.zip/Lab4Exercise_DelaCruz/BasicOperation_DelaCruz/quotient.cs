﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation_DelaCruz
{
    class quotient
    {
        public void ComputedQuo()
        {
            DeclaringVar.quotient = DeclaringVar.num1 / DeclaringVar.num2;
        }
    }
}
