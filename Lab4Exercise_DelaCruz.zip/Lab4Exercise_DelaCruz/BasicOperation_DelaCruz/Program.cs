﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation_DelaCruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Input inp = new Input();
            inp.InputValue();

            Sum s = new Sum();
            s.ComputedSum();
            Console.WriteLine("Sum: " + DeclaringVar.sum);
            Difference dif = new Difference();
            dif.ComputedDIfference();
            Console.WriteLine("Difference: " + DeclaringVar.difference);
            Product pro = new Product();
            pro.ComputedPro();
            Console.WriteLine("Product: " + DeclaringVar.product);
            quotient quo = new quotient();
            quo.ComputedQuo();
            Console.WriteLine("Quotient: " + DeclaringVar.quotient);
            Remainder rem = new Remainder();
            rem.ComputedRem();
            Console.WriteLine("Remainder: " + DeclaringVar.remainder);



            Console.ReadLine();
        }
    }
}
