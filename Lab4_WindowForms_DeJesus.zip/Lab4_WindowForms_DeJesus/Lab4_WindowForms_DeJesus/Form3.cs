﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4_WindowForms_DeJesus
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_profile_Click(object sender, EventArgs e)
        {
            MyProfile mp = new MyProfile();
            MessageBox.Show(mp.GetMessage(" " + textBox1.Text + " " + textBox2.Text));
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form2 fs = new Form2();
            fs.Show();
            this.Hide();

        }
    }
}
