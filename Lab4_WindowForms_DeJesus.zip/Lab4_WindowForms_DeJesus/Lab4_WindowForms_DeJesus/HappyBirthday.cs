﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_WindowForms_DeJesus
{
    class HappyBirthday
    {
        public String GetMessage(string firstname)
        {
            return "Happy Birthday" + firstname;
        }

    }
}
