﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4_WindowForms_DeJesus
{
    public partial class Form4 : Form
    {
        double firstnum, secondnum;
        public Form4()
        {
            InitializeComponent();
        }

        private void dif_Click(object sender, EventArgs e)
        {
            firstnum = Convert.ToDouble(textBox1.Text);
            secondnum = Convert.ToDouble(textBox2.Text);
            txt_ans.Text = (firstnum - secondnum).ToString();
        }

        private void mul_Click(object sender, EventArgs e)
        {
            firstnum = Convert.ToDouble(textBox1.Text);
            secondnum = Convert.ToDouble(textBox2.Text);
            txt_ans.Text = (firstnum * secondnum).ToString();
        }

        private void div_Click(object sender, EventArgs e)
        {
            firstnum = Convert.ToDouble(textBox1.Text);
            secondnum = Convert.ToDouble(textBox2.Text);
            txt_ans.Text = (firstnum / secondnum).ToString();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

        private void next_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void add_Click(object sender, EventArgs e)
        {
            firstnum = Convert.ToDouble(textBox1.Text);
            secondnum = Convert.ToDouble(textBox2.Text);
            txt_ans.Text = (firstnum + secondnum).ToString();
        }
    }
}
