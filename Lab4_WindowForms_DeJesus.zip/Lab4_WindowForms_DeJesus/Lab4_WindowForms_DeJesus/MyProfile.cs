﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_WindowForms_DeJesus
{
    class MyProfile
    {
        public String GetMessage(string firstname)
        {
            return "Hello" + firstname + "\nDate of Birth: October 30, 1999" + "\nCourse: BSCS" + "\nYear: II" + "\nSection: B" ;
        }
    }
}
