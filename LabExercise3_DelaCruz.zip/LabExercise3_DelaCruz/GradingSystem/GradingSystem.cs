﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradingSystem
{
    class GradingSystem
    {
        static void Main(string[] args)
        {
            double fnum;
            string grade;
            try
            {
                Console.WriteLine("Enter Grade: ");
                grade = Console.ReadLine();
                if (grade.Equals("inc") || grade.Equals("INC"))
                {
                    Console.WriteLine("Grade Quivalent:  INCOMPLETE");
                    Console.WriteLine("Remarks:     INCOMPLETE");
                }
                else
                {
                    fnum = Convert.ToDouble(grade);
                    fnum = Math.Round(fnum);
                if ((fnum >= 98) && (fnum <= 100))
                {
                    Console.WriteLine("Grade Quivalent:  1.00");
                    Console.WriteLine("Remarks:     Excellent");
                }
                else if ((fnum >= 95) && (fnum <= 97))
                {
                    Console.WriteLine("Grade Quivalent:  1.25");
                    Console.WriteLine("Remarks:     Excellent");
                }
                else if ((fnum <= 94) && (fnum >= 92))
                {
                    Console.WriteLine("Grade Quivalent:  1.50");
                    Console.WriteLine("Remarks:     Very Good");
                }
               else if ((fnum <= 91) && (fnum >= 89))
                {
                    Console.WriteLine("Grade Quivalent:  1.75");
                    Console.WriteLine("Remarks:     Very Good");
                }
               else if ((fnum <= 88) && (fnum >= 86))
                {
                    Console.WriteLine("Grade Quivalent:  2.00");
                    Console.WriteLine("Remarks:      Good");
                }
               else if ((fnum <= 85) && (fnum >= 83))
                {
                    Console.WriteLine("Grade Quivalent:  2.25");
                    Console.WriteLine("Remarks:     Good");
                }
               else if ((fnum <= 82) && (fnum >= 80))
                {
                    Console.WriteLine("Grade Quivalent:  2.50");
                    Console.WriteLine("Remarks:     Fair");
                }
               else if ((fnum <= 79)&& (fnum >= 77))
                {
                    Console.WriteLine("Grade Quivalent:  2.75");
                    Console.WriteLine("Remarks:     Passed");
                }
               else if ((fnum <= 76) && (fnum >= 75))
                {
                    Console.WriteLine("Grade Quivalent:  3.00");
                    Console.WriteLine("Remarks:     Passed");
                }
               else if ((fnum <= 74) && (fnum >= 72))
                {
                    Console.WriteLine("Grade Quivalent:  4.00");
                    Console.WriteLine("Remarks:     Conditional (MT only)");
                }
               else if (fnum <= 60)
                {
                    Console.WriteLine("Grade Quivalent:  5.00");
                    Console.WriteLine("Remarks:     Failed");
                }
                }
            }
            catch (FormatException error)
            {
                Console.WriteLine(error.Message);
            }
            Console.ReadKey();
        }
    }
}
