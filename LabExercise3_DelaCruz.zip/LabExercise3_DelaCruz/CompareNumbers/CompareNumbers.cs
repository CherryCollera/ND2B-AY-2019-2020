﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabExercise3_DelaCruz
{
    class CompareNumbers
    {
        static void Main(string[] args)
        {
            int fnum, snum, tnum;
            Console.Write("Enter First Number: ");
            fnum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            snum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            tnum = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");
            if ((fnum > snum) && (fnum > tnum))
            {
                Console.WriteLine(fnum + " Greater than " + snum + " and " + tnum);
                if (snum > tnum)
                {
                    Console.WriteLine(snum + " to Less than " + fnum);
                }

                Console.WriteLine(tnum + " to Less than " + fnum);

            }
          else  if ((snum > fnum) && (snum > tnum))
            {
                Console.WriteLine(snum + " Greater than " + fnum + " and " + tnum);
                if (fnum > tnum)
                {
                    Console.WriteLine(fnum + " to Less than " + snum);
                }
              
                    Console.WriteLine(tnum + " to Less than " + snum);
            }
          else  if ((tnum > fnum) && (tnum > snum))
            {
                Console.WriteLine(tnum + " Greater than " + fnum + " and " + snum);
                if (fnum > snum)
                {
                    Console.WriteLine(fnum + " to Less than " + tnum);
                }
                
                    Console.WriteLine(snum + " Less than " + tnum);
            }
            else
                Console.WriteLine(fnum + " Equal " + snum + " and " + tnum);


            Console.ReadKey();


            
            
            

            
        }
    }
}
