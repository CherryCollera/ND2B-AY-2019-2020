﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNames
{
    class CompareName
    {
        static void Main(string[] args)
        {
            string string1 = "Rhey";
            string string2 = "Rhey";
            string string3 = "Rheymel";
            string string4 = "rheymel";
            string string5 = "RHEYMEL";

            Console.WriteLine("Using Equal() Method");

            Console.WriteLine(" Compare {0} to {1}:{2}", string1,string2,string.Equals(string1,string2));
            Console.WriteLine(" Compare {0} to {1}:{2}", string1, string3, string.Equals(string1, string3));
            Console.WriteLine(" Length of {0} is {1}", string1,string1.Length);
            Console.WriteLine(" String {0} Substring(0,3) {1}:{2}", string5,string5, string5.Substring(0,3));

            Console.WriteLine("Using Compare() Method");

            Console.WriteLine(" Compare {0} to {1}:{2}", string1, string2, string.Compare(string1,string2));
            Console.WriteLine(" Compare {0} to {1}:{2}", string1, string3, string.Compare(string1, string3));
            Console.WriteLine(" Compare {0} to {1}:{2}", string3, string1, string.Compare(string3, string1));
            Console.WriteLine(" Compare {0} to {1}:{2}", string4, string5, string.Equals(string4, string5));

            Console.WriteLine("Using CompareTo() Method");
            Console.WriteLine(" Compare {0} to {1}:{2}", string1, string2, string1.CompareTo(string2));
            Console.WriteLine(" Compare {0} to {1}:{2}", string1, string3, string1.CompareTo(string3));
            Console.WriteLine(" Compare {0} to {1}:{2}", string3, string1, string3.CompareTo(string1));

            Console.ReadKey();
        }
    }
}
