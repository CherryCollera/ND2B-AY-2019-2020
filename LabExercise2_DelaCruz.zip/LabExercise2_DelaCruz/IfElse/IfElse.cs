﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse
{
    class IfElse
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            if(num1 < num2)
                Console.WriteLine(num1 +"Less than " + num2);
            
            else if(num2 > num1)
                Console.WriteLine(num2 + "Greater than " + num1);
            
            else
                Console.WriteLine(num1 + " Equal to " + num2);
            
            Console.ReadLine();
        }
    }
}
