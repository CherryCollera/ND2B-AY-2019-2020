﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclaringConstants
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
           int Radius;
            const double pi = 3.14159;
            Console.WriteLine("Enter Radius:  ");
            Radius = Convert.ToInt32(Console.ReadLine());
            Console.Write("Radius: {0:0.0000} " , Radius);
            Console.Write("Area: {0:0.0000}", (Radius * Radius * pi ));
            Console.ReadLine();
        }
    }
}
