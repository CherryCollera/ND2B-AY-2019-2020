﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Btn1_Integer_Click(object sender, EventArgs e)
        {
            int number = 25;
            MessageBox.Show(number.ToString());
        }

        private void Btn2_Float_Click(object sender, EventArgs e)
        {
            float number = 25.78F;
            MessageBox.Show(number.ToString());
        }

        private void Btn3_Double_Click(object sender, EventArgs e)
        {
            double number = 25.7889;
            MessageBox.Show(number.ToString());
        }

        private void Btn4_Compute_Sum_Click(object sender, EventArgs e)
        {
            int TxtBox1Number, TxtBox2Number, sum;
            TxtBox1Number = int.Parse(textBox1.Text);
            TxtBox2Number = int.Parse(textBox2.Text);
            sum = TxtBox1Number + TxtBox2Number;
            MessageBox.Show("Sum is " + sum.ToString());
        }
    }
}
