﻿namespace WindowsFormsApp2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn1_Integer = new System.Windows.Forms.Button();
            this.Btn2_Float = new System.Windows.Forms.Button();
            this.Btn3_Double = new System.Windows.Forms.Button();
            this.Btn4_Compute_Sum = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Btn1_Integer
            // 
            this.Btn1_Integer.Location = new System.Drawing.Point(13, 13);
            this.Btn1_Integer.Name = "Btn1_Integer";
            this.Btn1_Integer.Size = new System.Drawing.Size(75, 23);
            this.Btn1_Integer.TabIndex = 0;
            this.Btn1_Integer.Text = "Integer";
            this.Btn1_Integer.UseVisualStyleBackColor = true;
            this.Btn1_Integer.Click += new System.EventHandler(this.Btn1_Integer_Click);
            // 
            // Btn2_Float
            // 
            this.Btn2_Float.Location = new System.Drawing.Point(106, 13);
            this.Btn2_Float.Name = "Btn2_Float";
            this.Btn2_Float.Size = new System.Drawing.Size(75, 23);
            this.Btn2_Float.TabIndex = 1;
            this.Btn2_Float.Text = "Float";
            this.Btn2_Float.UseVisualStyleBackColor = true;
            this.Btn2_Float.Click += new System.EventHandler(this.Btn2_Float_Click);
            // 
            // Btn3_Double
            // 
            this.Btn3_Double.Location = new System.Drawing.Point(197, 13);
            this.Btn3_Double.Name = "Btn3_Double";
            this.Btn3_Double.Size = new System.Drawing.Size(75, 23);
            this.Btn3_Double.TabIndex = 2;
            this.Btn3_Double.Text = "Double";
            this.Btn3_Double.UseVisualStyleBackColor = true;
            this.Btn3_Double.Click += new System.EventHandler(this.Btn3_Double_Click);
            // 
            // Btn4_Compute_Sum
            // 
            this.Btn4_Compute_Sum.Location = new System.Drawing.Point(13, 227);
            this.Btn4_Compute_Sum.Name = "Btn4_Compute_Sum";
            this.Btn4_Compute_Sum.Size = new System.Drawing.Size(259, 23);
            this.Btn4_Compute_Sum.TabIndex = 3;
            this.Btn4_Compute_Sum.Text = "Compute Sum";
            this.Btn4_Compute_Sum.UseVisualStyleBackColor = true;
            this.Btn4_Compute_Sum.Click += new System.EventHandler(this.Btn4_Compute_Sum_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter first number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(169, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Enter second number:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 115);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(172, 115);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 7;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Btn4_Compute_Sum);
            this.Controls.Add(this.Btn3_Double);
            this.Controls.Add(this.Btn2_Float);
            this.Controls.Add(this.Btn1_Integer);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn1_Integer;
        private System.Windows.Forms.Button Btn2_Float;
        private System.Windows.Forms.Button Btn3_Double;
        private System.Windows.Forms.Button Btn4_Compute_Sum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}