﻿


class Declaration
{
    public string color
    {
        get
        {
            return color;

        }
        set
        {
            color = value;
        }
    }

}

