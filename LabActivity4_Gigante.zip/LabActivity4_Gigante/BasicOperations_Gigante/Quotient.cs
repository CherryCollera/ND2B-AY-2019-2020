﻿

using BasicOperations_Gigante;

class Quotient
{
    public double getQuotient(double a, double b)
    {
        double c = a / b;
        return c;
    }
}

