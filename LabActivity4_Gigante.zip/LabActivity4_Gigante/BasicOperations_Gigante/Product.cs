﻿
using BasicOperations_Gigante;

class Product
{
    public double getProduct(double a, double b)
    {
        double c = a * b;
        return c;
    }
}

