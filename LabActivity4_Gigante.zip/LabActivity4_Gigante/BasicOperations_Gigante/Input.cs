﻿

using BasicOperations_Gigante;

class Input
{
    public static double num, nums;
    public double num1()
    {
        System.Console.Write("Input first number: ");
        num = System.Convert.ToDouble(System.Console.ReadLine());
        return num;
    }
    public double num2()
    {
        System.Console.Write("Input second number: ");
        nums = System.Convert.ToDouble(System.Console.ReadLine());
        return nums;
    }
}
