﻿using System;


namespace BasicOperations_Gigante
{
    class Program
    {
        static void Main(string[] args)
        {
            Declarevar dv = new Declarevar();
            dv.Declaringvar();
            Console.ReadKey();
        }
    }
}
