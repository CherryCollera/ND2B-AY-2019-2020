﻿
using BasicOperations_Gigante;

class Sum
{
    public double AcceptSum(double a, double b)
    {
        double c = a + b;
        return c;
    }
}

