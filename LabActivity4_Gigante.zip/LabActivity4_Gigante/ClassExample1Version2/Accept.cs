﻿
class Accept
{
    public string firstname, lastname;
    public void AcceptDetails()
    {
        System.Console.Write("Enter Your Firstname and Lastname:\t");
        firstname = System.Console.ReadLine();
        lastname = System.Console.ReadLine();
    }
}
