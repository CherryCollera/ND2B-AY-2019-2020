﻿using System;

namespace ClassExample1Version2
{
    class Program
    {
        static void Main(string[] args)
        {
            Accept a = new Accept();
            a.AcceptDetails();


            Print p = new Print();
            p.PrintDetails(a.firstname, a.lastname);
            Console.ReadLine();
        }
    }
}
