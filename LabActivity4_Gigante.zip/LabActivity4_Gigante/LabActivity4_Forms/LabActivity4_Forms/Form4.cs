﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabActivity4_Forms
{
    public partial class Form4 : Form
    {
        double a, b, result;

        public Form4()
        {
            InitializeComponent();
        }


        private void button5_Click(object sender, EventArgs e)
        {
            Form3 ee = new Form3();
            ee.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);
            result = a - b;
            textBox3.Text = result.ToString("n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);
            result = a * b;
            textBox3.Text = result.ToString("n");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);
            result = a / b;
            textBox3.Text = result.ToString("n");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


       

        private void button1_Click(object sender, EventArgs e)
        {
            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);
            result = a + b;
            textBox3.Text = result.ToString("n");
        }
    }
}
