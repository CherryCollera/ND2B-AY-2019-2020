﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity4_Forms
{
    class GetMyProfile
    {
        public string GetMessage(string firstname)
        {
            return "\t\t" + "Hello " + firstname + "\n" + "Date of Birth" +"\t" + ":" + "\t" + "October 24, 1999" + "\n" + "Course" + "\t" + "\t" +":" + "\t" + "BS Comsci" + "\n" + "Year" + "\t" + "\t" + ":" + "\t" + "II" + "\n" + "Section" + "\t" +"\t" + ":" + "\t"  + " B";
        }
    }
}
