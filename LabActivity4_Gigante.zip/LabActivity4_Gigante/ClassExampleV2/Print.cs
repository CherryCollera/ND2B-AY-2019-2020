﻿using ClassExampleV2;
class Print
{
    public void PrintDetails()
    {
        InputColor a = new InputColor();
        a.AcceptDetails();
        System.Console.Write("The color of the cars are " + a.color1 +" and " + a.color2);
       
        InputColor ic = new InputColor();


    }


}

