﻿
class InputColor
{
    public string color1, color2;
    public void AcceptDetails()
    {
        System.Console.Write("Enter the color of the first car:\t");
        color1 = System.Console.ReadLine();
        System.Console.Write("Enter the color of the second car:\t");
        color2 = System.Console.ReadLine();

    }
}
