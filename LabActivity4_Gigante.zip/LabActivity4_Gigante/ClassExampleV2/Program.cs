﻿using System;

namespace ClassExampleV2
{
    class Program
{
    static void Main(string[] args)
    {
        Print p = new Print();
        p.PrintDetails();
        Console.ReadLine();
    }
}
}
