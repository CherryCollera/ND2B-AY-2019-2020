﻿using ClassExampleversion2;
class Print
{
    public void PrintDetails()
    {
        InputColor a = new InputColor();
        a.AcceptDetails();
        System.Console.Write("The color of the car is " + a.color1 + " " + a.color2 );
       InputColor ic = new InputColor();
     

    }


}

