﻿
class InputColor
{
    public string color1, color2;
    public void AcceptDetails()
    {
        System.Console.Write("Enter the color of the car:\t");
        color1 = System.Console.ReadLine();
        color2 = System.Console.ReadLine();
    }
}
