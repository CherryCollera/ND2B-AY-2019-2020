﻿using System;
/*18-01630
 * rheymel justine dela cruz
 * BSCS-ND2B
 * January 23, 2020
 * This program will display the text "Hello World"
 */


    namespace Sample1_HelloWorld_DelaCruz
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World");
            System.Console.ReadKey();
            Console.WriteLine("Rheymel Justine Dela Cruz");

        }
    }
}
