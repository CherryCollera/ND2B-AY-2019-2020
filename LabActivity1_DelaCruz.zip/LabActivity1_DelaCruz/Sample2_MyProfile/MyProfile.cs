﻿/*18-01630
 * rheymel justine dela cruz
 * BSCS-ND2B
 * January 23, 2020
 * This program will display name, date of birth, course, year and section
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample2_MyProfile
{
    class MyProfile
    {
        static void Main(string[] args)
        {
           
        }
    }
}
