﻿/*18-01630
 * rheymel justine dela cruz
 * BSCS-ND2B
 * January 23, 2020
 * This program will display name, date of birth, course, year and section.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample2_MyProfile1
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name:\t\t\t Dela Cruz Rheymel Justine B.");
            Console.WriteLine("Date of Birth:\t\t October 27, 1999");
            Console.WriteLine("Course:\t\t\t BSCS-ND");
            Console.WriteLine("Year And Section:\t 2B");
            Console.ReadKey();
        }
    }
}
