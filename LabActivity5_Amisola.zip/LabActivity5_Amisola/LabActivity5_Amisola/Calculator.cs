﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabActivity5_Amisola
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool plusButtonCliked = false;
        bool minusButtonCliked = false;
        bool divideButtonCliked = false;
        bool multiplyButtonCliked = false;


        public Calculator()
        {
            InitializeComponent();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnOne.Text;
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnTwo.Text;
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnThree.Text;
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnFour.Text;
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnFive.Text;
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnSix.Text;
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnSeven.Text;
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnEight.Text;
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnNine.Text;
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnZero.Text;
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void Clear_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void Backtoform1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 frm = new Form3();
            frm.Show();
        }

        private void Plus_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonCliked = false;
            plusButtonCliked = true;
            divideButtonCliked = false;
            multiplyButtonCliked = false;
        }

        private void Minus_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonCliked = true;
            plusButtonCliked = false;
            divideButtonCliked = false;
            multiplyButtonCliked = false;
        }

        private void Multiply_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonCliked = false;
            plusButtonCliked = false;
            divideButtonCliked = false;
            multiplyButtonCliked = true;
        }

        private void divide_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonCliked = false;
            plusButtonCliked = false;
            divideButtonCliked = true;
            multiplyButtonCliked = false;
        }

        private void Equal_Click(object sender, EventArgs e)
        {
            {
                if (plusButtonCliked == true)
                {
                    total2 = total1 + double.Parse(txtDisplay.Text);
                }
                else if (minusButtonCliked == true)
                {
                    total2 = total1 - double.Parse(txtDisplay.Text);
                }
                else if (multiplyButtonCliked == true)
                {
                    total2 = total1 * double.Parse(txtDisplay.Text);
                }
                else if (divideButtonCliked == true)
                {
                    total2 = total1 / double.Parse(txtDisplay.Text);
                }
                txtDisplay.Text = total2.ToString(); total1 = 0;
            }
        }
    }
}
