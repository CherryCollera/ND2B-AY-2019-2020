﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricBilling
{
    class Value
    {
        public int total, kilowatts;
        public string fn, ln;
        public const int basekilowatts = 20;

        public Value(string x, string y, int u)
        {
            fn = x;
            ln = y;
            kilowatts = u;
            total = basekilowatts * u;
        }
    }
}
