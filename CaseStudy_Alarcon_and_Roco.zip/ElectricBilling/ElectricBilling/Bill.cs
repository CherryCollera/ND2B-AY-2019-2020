﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricBilling
{
    class Bill
    {
        static void Msg()
        {
            Console.WriteLine("Bill Successfully Printed");
        }

        static void Main(string[] args)
        {

            string x, y;
            int u;

            Console.Write("\n" + "Enter Firstname: ");
            x = Console.ReadLine();
            Console.Write("\n" + "Enter Lastname: ");
            y = Console.ReadLine();
            Console.Write("\n" + "Enter the kilowatts used: ");
            u = Convert.ToInt32(Console.ReadLine());


            Value a = new Value(x, y, u);
            Console.WriteLine("\n" + a.fn + " " + a.ln + " " + "total bill is: " + a.total + "\n");
            Msg();
            Console.ReadLine();


        }
    }
}
