﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.InputValues();

            Sum sum = new Sum();
            sum.ComputeSum();
            System.Console.Write("Sum  =" + DeclareVar.sum + "\n\n") ;

            Difference dif = new Difference();
            dif.ComputeDifference();
            System.Console.Write("Difference = " + DeclareVar.difference + "\n\n");

            Product prod = new Product();
            prod.ComputeProduct();
            System.Console.Write("Product = " + DeclareVar.product + "\n\n");

            Quotient q = new Quotient();
            q.ComputeQuotient();
            System.Console.Write("Quotient  = " + DeclareVar.quotient + "\n\n");

            Remainder r = new Remainder();
            r.ComputeRemainder();
            System.Console.Write("Remainder  = " + DeclareVar.remainder + "\n\n");
            Console.ReadKey() ;

        }
    }
}
