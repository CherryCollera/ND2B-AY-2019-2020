﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
        }
    }
}
