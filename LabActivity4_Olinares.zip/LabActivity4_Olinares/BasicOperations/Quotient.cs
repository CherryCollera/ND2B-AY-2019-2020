﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
        }
    }
}
