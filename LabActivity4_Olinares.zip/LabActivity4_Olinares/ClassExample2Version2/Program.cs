﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2Version2
{
    class Program
    {
        
        static void Main(string[] args)
        {
            
            Car car1, car2;
            Console.WriteLine("Enter first color: ");
            car1 = new Car (Console.ReadLine());
            Console.WriteLine("Enter first color: ");
            car2 = new Car (Console.ReadLine());
            Console.WriteLine(car1.Describe());
            Console.WriteLine(car2.Describe());
            Console.ReadKey();


        }
    }
}
