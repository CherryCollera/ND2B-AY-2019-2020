﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1Version2
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            Console.WriteLine("Name:\t\t\tCherry Collera");
            Console.WriteLine("Birthday:\t\tMarch 1, 1999");
            Console.WriteLine("Course:\t\t\tBS Info Tech Major in Network " + "and Web Application");
            Console.WriteLine("Year:\t\t\t2nd Year");
            Console.WriteLine("Section:\t\tD");
            Console.ReadLine();
        }
    }
}
