﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1Version2
{
    class Print
    {
        
        public void PrintDetails(string firstname, string lastname)
        {
            //Accept a = new Accept();
            //a.AcceptDetails();

            Console.Write("Hello " + firstname + " " + lastname + 
                "!!!\n You have created classes in OOP");
        }
    }
}
