﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_DeJesus
{
    class DeclareVar
    {
       int num1, num2, sum, difference, product, qoutient, remainder;
    }
}
