﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_DeJesus
{
    class Sum
    {
        public void ComputeSum()
        {
            Console.WriteLine("Sum = {0}", num1 + num2);
            Console.ReadLine();

        }

    }
}
