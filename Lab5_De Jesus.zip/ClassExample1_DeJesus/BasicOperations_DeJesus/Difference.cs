﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_DeJesus
{
    class Difference
    {
        public void ComputeDifference()
        {
            Console.WriteLine("Difference = {0}", num1 - num2);
            Console.ReadLine();
        }
    }
}
