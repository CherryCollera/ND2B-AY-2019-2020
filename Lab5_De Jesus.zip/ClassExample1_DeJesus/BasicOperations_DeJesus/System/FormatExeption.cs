﻿using System.Runtime.Serialization;

namespace System
{
    [Serializable]
    internal class FormatExeption : Exception
    {
        public FormatExeption()
        {
        }

        public FormatExeption(string message) : base(message)
        {
        }

        public FormatExeption(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected FormatExeption(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}