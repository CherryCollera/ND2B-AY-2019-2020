﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_DeJesus
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("\nName:\t\t\tCherry Collera");
            System.Console.WriteLine("\nBirthday:\t\tMarch 1, 1999");
            System.Console.WriteLine("\nCourse:\t\t\tBS in Info Tech Major in Network and Web Application");
            System.Console.WriteLine("\nYear:\t\t\t2nd Year");
            System.Console.WriteLine("\nSection:\t\t\tA");
            System.Console.ReadLine();

        }
    }
}
