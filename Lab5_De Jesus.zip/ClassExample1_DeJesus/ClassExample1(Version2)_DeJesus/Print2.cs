﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Version2__DeJesus
{
    class Print2
    {
        public void PrintDetails(string firstname, string lastname)
        {
            System.Console.Write("Hello " + firstname + " " + lastname + "!!!\nYou have created classes in OOP");
        }
    }
}
