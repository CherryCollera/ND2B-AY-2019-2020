﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Version2__DeJesus
{
    class Program
    {
        static void Main(string[] args)
        {
            Accept2 a = new Accept2();
            a.AcceptDetails();

            Print2 p = new Print2();
            p.PrintDetails(a.firstname, a.lastname);

            MyProfile2 mp = new MyProfile2();
            mp.DisplayProfile();
            Console.ReadLine();
        }
    }
}
