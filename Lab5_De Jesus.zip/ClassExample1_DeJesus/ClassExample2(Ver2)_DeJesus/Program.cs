﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2_Ver2__DeJesus
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("");
            Console.WriteLine(car.Describe());
        
            car = new Car("");
            Console.WriteLine(car.Describe());
            Console.ReadLine();
        }
    }
}
