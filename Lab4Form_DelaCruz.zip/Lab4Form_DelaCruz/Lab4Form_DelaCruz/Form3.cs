﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4Form_DelaCruz
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_GetProfile_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("Hello " + txtb_Fname.Text +" "+ txtb_Lname.Text +"\n"
                + "Date of Birth:\t\t Oct.27 1999\n" + "Course:\t\t\t BS Computer Science Major in Network and Data Communication\n"+
                "Year: \t\t\t II\n" + "Section: \t\t\t B");
            Form4 fr4 = new Form4();
            fr4.Show();
            this.Hide();
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.Hide();
            f2.Show();
        }

        private void btn_b_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.Hide();
            f2.Show();
        }
    }
}
