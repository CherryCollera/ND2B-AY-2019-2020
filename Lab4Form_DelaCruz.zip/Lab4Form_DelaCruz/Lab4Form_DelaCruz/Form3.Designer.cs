﻿namespace Lab4Form_DelaCruz
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_GetProfile = new System.Windows.Forms.Button();
            this.btn_hide = new System.Windows.Forms.Button();
            this.btn_b = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtb_Fname = new System.Windows.Forms.TextBox();
            this.txtb_Lname = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_GetProfile
            // 
            this.btn_GetProfile.Location = new System.Drawing.Point(56, 210);
            this.btn_GetProfile.Name = "btn_GetProfile";
            this.btn_GetProfile.Size = new System.Drawing.Size(111, 23);
            this.btn_GetProfile.TabIndex = 0;
            this.btn_GetProfile.Text = "Get My Profile";
            this.btn_GetProfile.UseVisualStyleBackColor = true;
            this.btn_GetProfile.Click += new System.EventHandler(this.btn_GetProfile_Click);
            // 
            // btn_hide
            // 
            this.btn_hide.Location = new System.Drawing.Point(185, 210);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.Size = new System.Drawing.Size(75, 23);
            this.btn_hide.TabIndex = 0;
            this.btn_hide.Text = "Hide";
            this.btn_hide.UseVisualStyleBackColor = true;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // btn_b
            // 
            this.btn_b.Location = new System.Drawing.Point(294, 210);
            this.btn_b.Name = "btn_b";
            this.btn_b.Size = new System.Drawing.Size(75, 23);
            this.btn_b.TabIndex = 0;
            this.btn_b.Text = "Back";
            this.btn_b.UseVisualStyleBackColor = true;
            this.btn_b.Click += new System.EventHandler(this.btn_b_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name: ";
            // 
            // txtb_Fname
            // 
            this.txtb_Fname.Location = new System.Drawing.Point(122, 45);
            this.txtb_Fname.Name = "txtb_Fname";
            this.txtb_Fname.Size = new System.Drawing.Size(216, 20);
            this.txtb_Fname.TabIndex = 3;
            // 
            // txtb_Lname
            // 
            this.txtb_Lname.Location = new System.Drawing.Point(122, 97);
            this.txtb_Lname.Name = "txtb_Lname";
            this.txtb_Lname.Size = new System.Drawing.Size(216, 20);
            this.txtb_Lname.TabIndex = 3;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 304);
            this.Controls.Add(this.txtb_Lname);
            this.Controls.Add(this.txtb_Fname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_b);
            this.Controls.Add(this.btn_hide);
            this.Controls.Add(this.btn_GetProfile);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_GetProfile;
        private System.Windows.Forms.Button btn_hide;
        private System.Windows.Forms.Button btn_b;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtb_Fname;
        private System.Windows.Forms.TextBox txtb_Lname;
    }
}