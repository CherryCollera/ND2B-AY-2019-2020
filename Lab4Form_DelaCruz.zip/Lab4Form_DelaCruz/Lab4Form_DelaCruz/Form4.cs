﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4Form_DelaCruz
{
    public partial class Form4 : Form
    {
        double fnum, Snum, ans;
        public Form4()
        {
            
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form3 fr3 = new Form3();
            fr3.Show();
            this.Hide();
        }

        private void btn_Sub_Click(object sender, EventArgs e)
        {
            fnum = Convert.ToDouble(txtb_fnum.Text);
            Snum = Convert.ToDouble(txtb_Snum.Text);
            ans = fnum - Snum;
            txtb_ans.Text = ans.ToString();
        }

        private void btn_Pro_Click(object sender, EventArgs e)
        {
            fnum = Convert.ToDouble(txtb_fnum.Text);
            Snum = Convert.ToDouble(txtb_Snum.Text);
            ans = fnum * Snum;
            txtb_ans.Text = ans.ToString();
        }

        private void btn_Quo_Click(object sender, EventArgs e)
        {
            fnum = Convert.ToDouble(txtb_fnum.Text);
            Snum = Convert.ToDouble(txtb_Snum.Text);
            ans = fnum / Snum;
            txtb_ans.Text = ans.ToString();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            fnum = Convert.ToDouble(txtb_fnum.Text);
             Snum = Convert.ToDouble(txtb_Snum.Text);
             ans = fnum + Snum;
            txtb_ans.Text = ans.ToString();
        }
    }
}
