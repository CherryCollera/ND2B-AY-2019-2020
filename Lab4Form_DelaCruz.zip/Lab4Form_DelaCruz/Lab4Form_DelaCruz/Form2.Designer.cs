﻿namespace Lab4Form_DelaCruz
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Msg = new System.Windows.Forms.Button();
            this.txtB_Fname = new System.Windows.Forms.TextBox();
            this.txtb_Lname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Hide = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Msg
            // 
            this.btn_Msg.Location = new System.Drawing.Point(97, 153);
            this.btn_Msg.Name = "btn_Msg";
            this.btn_Msg.Size = new System.Drawing.Size(114, 39);
            this.btn_Msg.TabIndex = 0;
            this.btn_Msg.Text = "Get Message";
            this.btn_Msg.UseVisualStyleBackColor = true;
            this.btn_Msg.Click += new System.EventHandler(this.btn_Msg_Click);
            // 
            // txtB_Fname
            // 
            this.txtB_Fname.Location = new System.Drawing.Point(110, 36);
            this.txtB_Fname.Name = "txtB_Fname";
            this.txtB_Fname.Size = new System.Drawing.Size(139, 20);
            this.txtB_Fname.TabIndex = 1;
            // 
            // txtb_Lname
            // 
            this.txtb_Lname.Location = new System.Drawing.Point(110, 62);
            this.txtb_Lname.Name = "txtb_Lname";
            this.txtb_Lname.Size = new System.Drawing.Size(139, 20);
            this.txtb_Lname.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "First Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name:";
            // 
            // btn_Hide
            // 
            this.btn_Hide.Location = new System.Drawing.Point(219, 230);
            this.btn_Hide.Name = "btn_Hide";
            this.btn_Hide.Size = new System.Drawing.Size(75, 23);
            this.btn_Hide.TabIndex = 3;
            this.btn_Hide.Text = "Hide";
            this.btn_Hide.UseVisualStyleBackColor = true;
            this.btn_Hide.Click += new System.EventHandler(this.btn_Hide_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 269);
            this.Controls.Add(this.btn_Hide);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtb_Lname);
            this.Controls.Add(this.txtB_Fname);
            this.Controls.Add(this.btn_Msg);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Msg;
        private System.Windows.Forms.TextBox txtB_Fname;
        private System.Windows.Forms.TextBox txtb_Lname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Hide;
    }
}