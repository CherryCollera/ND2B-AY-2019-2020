﻿namespace LabActivity6_Gigante
{


    partial class studentsDataSet
    {
    }
}

namespace LabActivity6_Gigante.studentsDataSetTableAdapters {
    
    
    public partial class tblStudent_InfoTableAdapter {
    }
}
