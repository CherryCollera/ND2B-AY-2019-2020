﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAct4_Olinares_WindowsForm
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday " + firstname;
        }
    }
}
