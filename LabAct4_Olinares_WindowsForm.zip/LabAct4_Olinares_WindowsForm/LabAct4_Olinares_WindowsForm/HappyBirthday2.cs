﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAct4_Olinares_WindowsForm
{
    class HappyBirthday2
    {
        public string GetMessage2(string firstname)
        {
            return "Happy Birthday " + firstname;
        }
    }
}
