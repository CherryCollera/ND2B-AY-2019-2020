﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabAct4_Olinares_WindowsForm
{
    public partial class Form4 : Form
    {
        double num1, num2;
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_Minus_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(txtbox_num1.Text);
            num2 = Convert.ToDouble(txtbox_num2.Text);
            txtbox_Ans.Text = (num1 - num2).ToString();
        }

        private void btn_Multiply_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(txtbox_num1.Text);
            num2 = Convert.ToDouble(txtbox_num2.Text);
            txtbox_Ans.Text = (num1 * num2).ToString();
        }

        private void btn_Divide_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(txtbox_num1.Text);
            num2 = Convert.ToDouble(txtbox_num2.Text);
            txtbox_Ans.Text = (num1 / num2).ToString();
        }

        private void btn_Plus_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(txtbox_num1.Text);
            num2 = Convert.ToDouble(txtbox_num2.Text);
            txtbox_Ans.Text = (num1 + num2).ToString();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
