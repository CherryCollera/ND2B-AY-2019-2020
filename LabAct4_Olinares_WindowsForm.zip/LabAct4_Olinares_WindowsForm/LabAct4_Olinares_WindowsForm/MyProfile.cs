﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAct4_Olinares_WindowsForm
{
    class MyProfile
    {
        public string GetProfile(string firstname)
        {
            return "\t\tHello " + firstname +
                "\nDate of Birth\t :\tSeptember 29, 1999" + "\nCourse\t\t:\tBS Computer Science"
                + "\nYear\t\t :\tII" + "\nSection\t\t:\tB";

        }
    }
}
